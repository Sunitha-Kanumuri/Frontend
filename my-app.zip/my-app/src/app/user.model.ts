export class User {
    name: string = "";
    phone: string = "";
    age: string = "";
    address: string = "";
    email: string = "";
    password: string = "";
}