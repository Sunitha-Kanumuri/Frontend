import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { User } from './user.model';

@Injectable({
  providedIn: 'root'
})
export class RegisterationService {
  BaseUrl = environment.BaseUrl;
  constructor(private httpClient: HttpClient) { }

  saveUserData(userData: User) {
    const url = this.BaseUrl + "/register"
    return this.httpClient.post(url, userData);
  }
}
