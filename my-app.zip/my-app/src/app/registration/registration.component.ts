import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterationService } from '../registeration.service';
import { User } from '../user.model';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  userForm: any;
  user: User;
  constructor(private formBuilder: FormBuilder, private registerationService: RegisterationService) {
    this.user = new User()
   }

  ngOnInit(): void {
    this.userForm = this.formBuilder.group({
      name: ['', Validators.required],
      phone: ['', Validators.required],
      age: ['', Validators.required],
      address: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  register() {
    if(this.userForm.valid) {
      this.user.name = this.userForm.get('name').value;
      this.user.phone = this.userForm.get('phone').value;
      this.user.age = this.userForm.get('age').value;
      this.user.address = this.userForm.get('address').value;
      this.user.email = this.userForm.get('password').value;
    }
    this.registerationService.saveUserData(this.user).subscribe((res: any) => {
      alert('Registered Successfully')
    }, (error) => {
      alert('Registered Failed')
    });
  }

}
